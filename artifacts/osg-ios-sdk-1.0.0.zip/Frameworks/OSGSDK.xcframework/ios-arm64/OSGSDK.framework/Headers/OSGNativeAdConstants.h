//
//  OSGNativeAdConstants.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

extern const CGFloat kUniversalStarRatingScale;
extern const CGFloat kStarRatingMaxValue;
extern const CGFloat kStarRatingMinValue;
extern const NSTimeInterval kDefaultRequiredSecondsForImpression;

/**
 Return from `OSGNativeViewSizeHandler` for variable-height frame-based native ad layout.
 */
FOUNDATION_EXPORT const CGFloat OSGNativeViewFrameBasedDynamicDimension;

/**
 Return from `OSGNativeViewSizeHandler` for variable-height Auto Layout-based native ad layout.
 */
FOUNDATION_EXPORT const CGFloat OSGNativeViewAutoLayoutBasedDynamicDimension;

/** @name OSGNativeAd asset keys */

extern NSString *const kAdTitleKey;
extern NSString *const kAdTextKey;
extern NSString *const kAdIconImageKey;
extern NSString *const kAdIconImageViewKey;
extern NSString *const kAdMainImageKey;
extern NSString *const kAdSponsoredByCompanyKey;
extern NSString *const kAdMainMediaViewKey;
extern NSString *const kAdCTATextKey;
extern NSString *const kAdStarRatingKey;
extern NSString *const kVideoConfigKey;
extern NSString *const kVASTVideoKey;
extern NSString *const kNativeAdConfigKey;
extern NSString *const kAdPrivacyIconImageUrlKey;
extern NSString *const kAdPrivacyIconUIImageKey;
extern NSString *const kAdPrivacyIconClickUrlKey;

extern NSString *const kPrivacyIconImageName;
extern NSString *const kPrivacyIconTapDestinationURL;
extern NSString *const kDefaultActionURLKey;
extern NSString *const kClickTrackerURLKey;

extern NSString *const kNativeAdUnitId;
extern NSString *const kNativeAdDspCreativeId;
extern NSString *const kNativeAdDspName;
