//
//  OSGAd.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import "OSGImpressionData.h"

NS_ASSUME_NONNULL_BEGIN

@protocol OSGAdDelegate;

/**
 This protocol defines functionality that is shared between all MoPub ads.
 */
@protocol OSGAd <NSObject>

@required
/**
 All MoPub ads have a delegate to call back when certain events occur.
 */
@property (nonatomic, weak, nullable) id<OSGAdDelegate> delegate;

@end

/**
 This protocol defines callback events shared between all MoPub ads.
 */
@protocol OSGAdDelegate <NSObject>

@optional
/**
 Called when an impression is fired on the @c OSGAd instance. Includes information about the impression if applicable.

 @param ad The @c OSGAd instance that fired the impression
 @param impressionData Information about the impression, or @c nil if the server didn't return any information.
 */
- (void)mopubAd:(id<OSGAd>)ad didTrackImpressionWithImpressionData:(OSGImpressionData * _Nullable)impressionData;

@end

NS_ASSUME_NONNULL_END
