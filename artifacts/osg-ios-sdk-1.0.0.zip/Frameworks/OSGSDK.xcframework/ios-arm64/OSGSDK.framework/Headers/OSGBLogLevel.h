//
//  OSGBLogLevel.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>

/**
 SDK logging level. The "MPB" prefix is used instead of "MP" to avoid namespace collision.
 @remark Lower values equate to more detailed logs.
 */
typedef NS_ENUM(NSUInteger, OSGBLogLevel) {
    OSGBLogLevelDebug = 20,
    OSGBLogLevelInfo  = 30,
    OSGBLogLevelNone  = 70
};
