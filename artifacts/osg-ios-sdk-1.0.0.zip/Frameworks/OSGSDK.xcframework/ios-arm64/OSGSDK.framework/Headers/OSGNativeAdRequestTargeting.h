//
//  OSGNativeAdRequestTargeting.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import "OSGAdTargeting.h"

/**
 The @c OSGNativeAdRequestTargeting class is used to attach targeting information to
 @c OSGNativeAdRequest objects.
 */
@interface OSGNativeAdRequestTargeting : OSGAdTargeting

/**
 Creates and returns an empty @c OSGNativeAdRequestTargeting object.
 @return A newly initialized @c OSGNativeAdRequestTargeting object.
 */
+ (OSGNativeAdRequestTargeting *)targeting;

/**
 A set of defined strings that correspond to assets for the intended native ad
 object. This set should contain only those assets that will be displayed in the ad.

 The MoPub ad server will attempt to only return the assets in @c desiredAssets.
 */
@property (nonatomic, strong) NSSet * desiredAssets;

@end
