//
//  OSGConsentChangedReason.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>

extern NSString * const kConsentedChangedReasonGranted;
extern NSString * const kConsentedChangedReasonWhitelistGranted;
extern NSString * const kConsentedChangedReasonPotentialWhitelist;
extern NSString * const kConsentedChangedReasonDenied;
extern NSString * const kConsentedChangedReasonPublisherDenied;
extern NSString * const kConsentedChangedReasonDoNotTrackEnabled;
extern NSString * const kConsentedChangedReasonDoNotTrackDisabled;
extern NSString * const kConsentedChangedReasonDoNotTrackDisabledNeedConsent;
extern NSString * const kConsentedChangedReasonDoNotTrackDisabledPreserveConsent;
extern NSString * const kConsentedChangedReasonIfaChanged;
extern NSString * const kConsentedChangedReasonPrivacyPolicyChange;
extern NSString * const kConsentedChangedReasonVendorListChange;
extern NSString * const kConsentedChangedReasonIabVendorListChange;
extern NSString * const kConsentedChangedReasonServerDeniedConsent;
extern NSString * const kConsentedChangedReasonServerForceInvalidate;
