//
//  OSGStreamAdPlacerDelegate.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import "OSGAdPlacer.h"

@class OSGStreamAdPlacer;

@protocol OSGStreamAdPlacerDelegate <OSGAdPlacerDelegate>

@optional
- (void)adPlacer:(OSGStreamAdPlacer *)adPlacer didLoadAdAtIndexPath:(NSIndexPath *)indexPath;
- (void)adPlacer:(OSGStreamAdPlacer *)adPlacer didRemoveAdsAtIndexPaths:(NSArray *)indexPaths;

/*
 This method is called when a native ad, placed by the stream ad placer, will present a modal view controller.

 @param placer The stream ad placer that contains the ad displaying the modal.
 */
- (void)nativeAdWillPresentModalForStreamAdPlacer:(OSGStreamAdPlacer *)adPlacer;

/*
 This method is called when a native ad, placed by the stream ad placer, did dismiss its modal view controller.

 @param placer The stream ad placer that contains the ad that dismissed the modal.
 */
- (void)nativeAdDidDismissModalForStreamAdPlacer:(OSGStreamAdPlacer *)adPlacer;

/*
 This method is called when a native ad, placed by the stream ad placer, will cause the app to background due to user interaction with the ad.

 @param placer The stream ad placer that contains the ad causing the app to background.
 */
- (void)nativeAdWillLeaveApplicationFromStreamAdPlacer:(OSGStreamAdPlacer *)adPlacer;

@end
