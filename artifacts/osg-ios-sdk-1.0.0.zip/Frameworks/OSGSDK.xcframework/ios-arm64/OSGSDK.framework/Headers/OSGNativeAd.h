//
//  OSGNativeAd.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OSGAd.h"
#import "OSGNativeAdDelegate.h"

@protocol OSGNativeAdAdapter;
@protocol OSGNativeAdRenderer;
@class OSGAdConfiguration;

/**
 The `OSGNativeAd` class is used to render and manage events for a native advertisement. The
 class provides methods for accessing native ad properties returned by the server, as well as
 convenience methods for URL navigation and metrics-gathering.
 */

@interface OSGNativeAd : NSObject <OSGAd>

/** @name Ad Resources */

/**
 The delegate of the `OSGNativeAd` object.
 */
@property (nonatomic, weak) id<OSGNativeAdDelegate> delegate;

/**
 A dictionary representing the native ad properties.
 */
@property (nonatomic, readonly) NSDictionary *properties;

- (instancetype)initWithAdAdapter:(id<OSGNativeAdAdapter>)adAdapter;

/** @name Retrieving Ad View */

/**
 Retrieves a rendered view containing the ad.

 @param error A pointer to an error object. If an error occurs, this pointer will be set to an
 actual error object containing the error information.

 @return If successful, the method will return a view containing the rendered ad. The method will
 return nil if it cannot render the ad data to a view.
 */
- (UIView *)retrieveAdViewWithError:(NSError **)error;

- (void)trackMetricForURL:(NSURL *)URL;

@end
