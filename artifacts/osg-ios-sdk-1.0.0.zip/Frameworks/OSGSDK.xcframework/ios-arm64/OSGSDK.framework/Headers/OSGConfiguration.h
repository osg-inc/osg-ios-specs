//
//  OSGConfiguration.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import "OSGAdapterConfiguration.h"
#import "OSGBLogLevel.h"
#import "OSGMediationSettingsProtocol.h"
#import "OSGRewardedAds.h"

NS_ASSUME_NONNULL_BEGIN

@interface OSGConfiguration : NSObject
/**
 Optional list of additional mediated network SDKs to pre-initialize from the cache. If the mediated network
 SDK has no cache entry, nothing will be done.
 @remarks All certified mediated networks will be pre-initialized. This property is meant to pre-initialize
 any custom adapters that have not been certified.
 */
@property (nonatomic, strong, nullable) NSArray<Class<OSGAdapterConfiguration>> * additionalNetworks;

/**
 Any valid ad unit ID used within the app used for app initialization.
 @remark This is a required field.
 */
@property (nonatomic, strong, nonnull) NSString * adUnitIdForAppInitialization;

/**
 This API can be used if you want to allow supported SDK networks to collect user information on the basis of legitimate interest. The default value is @c NO.
 */
@property (nonatomic, assign) BOOL allowLegitimateInterest;

/**
 Optional global configurations for all ad networks your app supports.
 */
@property (nonatomic, strong, nullable) NSArray<id<OSGMediationSettingsProtocol>> * globalMediationSettings;

/**
 Optional logging level. By default, this value is set to @c OSGBLogLevelNone.
 */
@property (nonatomic, assign) OSGBLogLevel loggingLevel;

/**
 Optional configuration settings for mediated networks during initialization. To add entries
 to this dictionary, use the convenience method @c setNetworkConfiguration:forMediationAdapter:
 */
@property (nonatomic, strong, nullable) NSMutableDictionary<NSString *, NSDictionary<NSString *, id> *> * mediatedNetworkConfigurations;

/**
 Optional request options for mediated networks. To add entries
 to this dictionary, use the convenience method @c setMoPubRequestOptions:forMediationAdapter:
 */
@property (nonatomic, strong, nullable) NSMutableDictionary<NSString *, NSDictionary<NSString *, NSString *> *> * moPubRequestOptions;

#pragma mark - 本地化自建广告服务器（v2 协议）扩展配置

/**
 应用 ID（对应 v2 协议 @c appid 字段）。可选，如设置则在所有 v2 请求中携带。
 */
@property (nonatomic, copy, nullable) NSString *appId;

/**
 应用 Key（对应 v2 协议 @c app_key 字段）。可选，如设置则在 /v2/ads 请求中携带。
 */
@property (nonatomic, copy, nullable) NSString *appKey;

/**
 测试模式（对应 v2 协议 @c test 字段）。@c YES 时 /v2/ads 请求会标记为测试请求。默认 @c NO。
 */
@property (nonatomic, assign) BOOL testMode;

/**
 Initializes the @c OSGConfiguration object with the required fields.
 @param adUnitId Any valid ad unit ID used within the app used for app initialization.
 @return A configuration instance.
 */
- (instancetype)initWithAdUnitIdForAppInitialization:(NSString *)adUnitId NS_DESIGNATED_INITIALIZER;

/**
 Sets the network configuration options for a given mediated network class name.
 @param configuration Configuration parameters specific to the network. Only @c NSString, @c NSNumber, @c NSArray, and @c NSDictionary types are allowed. This value may be @c nil.
 @param adapterClassName The class name of the mediated adapter that will receive the inputted configuration. The adapter class must implement the @c OSGAdapterConfiguration protocol.
 */
- (void)setNetworkConfiguration:(NSDictionary<NSString *, id> * _Nullable)configuration
            forMediationAdapter:(NSString *)adapterClassName;

/**
 Sets the mediated network's request options.
 @param options Request options for the mediated network.
 @param adapterClassName The class name of the mediated adapter that will receive the inputted configuration. The adapter class must implement the @c OSGAdapterConfiguration protocol.
 */
- (void)setMoPubRequestOptions:(NSDictionary<NSString *, NSString *> * _Nullable)options
           forMediationAdapter:(NSString *)adapterClassName;

/**
 Usage of default initializer is disallowed. Use @c initWithAdUnitIdForAppInitialization: instead.
 */
- (instancetype)init NS_UNAVAILABLE;

/**
 Usage of @c new is disallowed. Use @c initWithAdUnitIdForAppInitialization: instead.
 */
+ (instancetype)new NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
