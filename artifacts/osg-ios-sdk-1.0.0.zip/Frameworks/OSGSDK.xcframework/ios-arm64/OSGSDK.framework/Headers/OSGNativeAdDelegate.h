//
//  OSGNativeAdDelegate.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import "OSGAd.h"

/**
 The delegate of an `OSGNativeAd` object must adopt the `OSGNativeAdDelegate` protocol. It must
 implement `viewControllerForPresentingModalView` to provide a root view controller from which
 the ad view should present modal content.
 */
@class OSGNativeAd;
@protocol OSGNativeAdDelegate <OSGAdDelegate>

@optional

/**
 Sent when the native ad will present its modal content.

 @param nativeAd The native ad sending the message.
 */
- (void)willPresentModalForNativeAd:(OSGNativeAd *)nativeAd;

/**
 Sent when a native ad has dismissed its modal content, returning control to your application.

 @param nativeAd The native ad sending the message.
 */
- (void)didDismissModalForNativeAd:(OSGNativeAd *)nativeAd;

/**
 Sent when a user is about to leave your application as a result of tapping this native ad.

 @param nativeAd The native ad sending the message.
 */
- (void)willLeaveApplicationFromNativeAd:(OSGNativeAd *)nativeAd;

@required

/** @name Managing Modal Content Presentation */

/**
 Asks the delegate for a view controller to use for presenting modal content, such as the in-app
 browser that can appear when an ad is tapped.

 @return A view controller that should be used for presenting modal content.
 */
- (UIViewController *)viewControllerForPresentingModalView;

@end
