//
//  OSGRewardedVideoReward.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import "OSGReward.h"

/**
 A constant that indicates that no currency type was specified with the reward.
 @deprecated This API is deprecated and will be removed in a future version.
 */
extern NSString *const kOSGRewardedVideoRewardCurrencyTypeUnspecified DEPRECATED_MSG_ATTRIBUTE("Use `kOSGRewardCurrencyTypeUnspecified` instead.");

/**
 A constant that indicates that no currency amount was specified with the reward.
 @deprecated This API is deprecated and will be removed in a future version.
 */
extern NSInteger const kOSGRewardedVideoRewardCurrencyAmountUnspecified DEPRECATED_MSG_ATTRIBUTE("Use `kOSGRewardCurrencyAmountUnspecified` instead.");

/**
 @c OSGRewardedVideoReward is deprecated. Please use @c OSGReward instead.
 */
DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoReward is deprecated. Please use OSGReward instead.")
@interface OSGRewardedVideoReward : OSGReward

+ (OSGRewardedVideoReward *)rewardWithReward:(OSGReward *)reward DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoReward is deprecated. Please use OSGReward instead.");

@end
