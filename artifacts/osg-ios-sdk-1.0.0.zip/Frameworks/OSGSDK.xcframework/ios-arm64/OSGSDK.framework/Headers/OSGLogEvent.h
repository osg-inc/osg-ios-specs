//
//  OSGLogEvent.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import "OSGConsentStatus.h"
#import "OSGBLogLevel.h"

@protocol OSGAdapterConfiguration;
@protocol OSGViewabilityObstruction;
@protocol OSGViewabilityTracker;
@class OSGReward;
@class OSGURLRequest;

NS_ASSUME_NONNULL_BEGIN

/**
 Logging event used to construct pre-formatted messages.
 */
@interface OSGLogEvent : NSObject
/**
 Message to be logged.
 */
@property (nonatomic, copy, readonly) NSString * message;

/**
 Level at which the message should be logged.
 */
@property (nonatomic, assign, readonly) OSGBLogLevel logLevel;

/**
 Default initialization is disallowed.
 */
- (instancetype)init NS_UNAVAILABLE;

/**
 Initializes the log event with the specified message to be logged at Debug level.
 @param message Message to log
 @return Log event
 */
- (instancetype)initWithMessage:(NSString *)message;

/**
 Initializes the log event with the specified message to be logged at the desired
 log level.
 @param message Message to log
 @param level Level at which the message should be logged
 @return Log event
 */
- (instancetype)initWithMessage:(NSString *)message level:(OSGBLogLevel)level NS_DESIGNATED_INITIALIZER;

/**
 Initializes a generic error log event with optional message. The message and error
 will be logged at Debug level.
 @param error Error to log
 @param message Optional message that will prefix the error message.
 @return Log event
 */
+ (instancetype)error:(NSError *)error message:(NSString * _Nullable)message;

/**
 Initializes the log event with the specified message to be logged at the desired
 log level.
 @param message Message to log
 @param level Level at which the message should be logged
 @return Log event
 */
+ (instancetype)eventWithMessage:(NSString *)message level:(OSGBLogLevel)level;

@end

@interface OSGLogEvent (AdLifeCycle)
+ (instancetype)adRequestedWithRequest:(OSGURLRequest *)request;
+ (instancetype)adRequestReceivedResponse:(NSDictionary *)response;
+ (instancetype)adLoadAttempt;
+ (instancetype)adShowAttempt;
+ (instancetype)adShowSuccess;
+ (instancetype)adShowFailedWithError:(NSError *)error;
+ (instancetype)adDidLoad;
+ (instancetype)adFailedToLoadWithError:(NSError *)error;
+ (instancetype)adExpiredWithTimeInterval:(NSTimeInterval)expirationInterval;
+ (instancetype)adWillPresentModal;
+ (instancetype)adDidDismissModal;
+ (instancetype)adTapped;
+ (instancetype)adWillPresent;
+ (instancetype)adDidPresent;
+ (instancetype)adWillDismiss;
+ (instancetype)adDidDismiss;
+ (instancetype)adShouldRewardUserWithReward:(OSGReward *)reward;
+ (instancetype)adWillLeaveApplication;
@end

@interface OSGLogEvent (AdapterAdLifeCycle)
+ (instancetype)adLoadAttemptForAdapter:(NSString *)name dspCreativeId:(NSString * _Nullable)creativeId dspName:(NSString * _Nullable)dspName;
+ (instancetype)adLoadSuccessForAdapter:(NSString *)name;
+ (instancetype)adLoadFailedForAdapter:(NSString *)name error:(NSError *)error;
+ (instancetype)adShowAttemptForAdapter:(NSString *)name;
+ (instancetype)adShowSuccessForAdapter:(NSString *)name;
+ (instancetype)adShowFailedForAdapter:(NSString *)name error:(NSError *)error;
+ (instancetype)adWillPresentModalForAdapter:(NSString *)name;
+ (instancetype)adDidDismissModalForAdapter:(NSString *)name;
+ (instancetype)adTappedForAdapter:(NSString *)name;
+ (instancetype)adWillAppearForAdapter:(NSString *)name;
+ (instancetype)adDidAppearForAdapter:(NSString *)name;
+ (instancetype)adWillDisappearForAdapter:(NSString *)name;
+ (instancetype)adDidDisappearForAdapter:(NSString *)name;
+ (instancetype)adWillLeaveApplicationForAdapter:(NSString *)name;
@end

@interface OSGLogEvent (Initialization)
+ (instancetype)sdkInitializedWithNetworks:(NSArray<id<OSGAdapterConfiguration>> *)networks;
@end

@interface OSGLogEvent (Consent)
+ (instancetype)consentSyncAttempted;
+ (instancetype)consentSyncCompletedWithMessage:(NSString * _Nullable)message;
+ (instancetype)consentSyncFailedWithError:(NSError *)error;
+ (instancetype)consentUpdatedTo:(OSGConsentStatus)newStatus from:(OSGConsentStatus)oldStatus reason:(NSString * _Nullable)reason canCollectPersonalInfo:(BOOL)canCollectPII;
+ (instancetype)consentShouldShowDialog;
+ (instancetype)consentDialogLoadAttempted;
+ (instancetype)consentDialogLoadSuccess;
+ (instancetype)consentDialogLoadFailedWithError:(NSError *)error;
+ (instancetype)consentDialogShowAttempted;
+ (instancetype)consentDialogShowSuccess;
+ (instancetype)consentDialogShowFailedWithError:(NSError *)error;
@end

@interface OSGLogEvent (Javascript)
+ (instancetype)javascriptConsoleLogWithMessage:(NSString *)message;
@end

@interface OSGLogEvent (Viewability)
+ (instancetype)viewabilityDisabled;
+ (instancetype)viewabilityTrackerCreated:(id<OSGViewabilityTracker>)tracker;
+ (instancetype)viewabilityTrackerDeallocated:(id<OSGViewabilityTracker>)tracker;
+ (instancetype)viewabilityTrackerSessionStarted:(id<OSGViewabilityTracker>)tracker;
+ (instancetype)viewabilityTrackerSessionStopped:(id<OSGViewabilityTracker>)tracker;
+ (instancetype)viewabilityTrackerUpdatedTrackingView:(id<OSGViewabilityTracker>)tracker;
+ (instancetype)viewabilityTrackerTrackedAdLoaded:(id<OSGViewabilityTracker>)tracker;
+ (instancetype)viewabilityTrackerTrackedImpression:(id<OSGViewabilityTracker>)tracker;
+ (instancetype)viewabilityTracker:(id<OSGViewabilityTracker>)tracker trackedVideoEvent:(NSString *)event;
+ (instancetype)viewabilityTracker:(id<OSGViewabilityTracker>)tracker addedFriendlyObstruction:(id<OSGViewabilityObstruction>)obstruction;
@end

NS_ASSUME_NONNULL_END
