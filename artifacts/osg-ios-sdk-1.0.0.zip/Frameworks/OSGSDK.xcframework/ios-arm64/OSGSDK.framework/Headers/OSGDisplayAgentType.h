//
//  OSGDisplayAgentType.h
//
//  Copyright 2025-2026 OSG, Inc.
//

typedef NS_ENUM(NSInteger, OSGDisplayAgentType) {
    /**
     Use in-app views for display agent without escaping the app. @c SFSafariViewController is used
     for web browsing, and @c SKStoreProductViewController is used for supported App Store links.
     */
    OSGDisplayAgentTypeInApp = 0,

    /**
     Use the iOS Native Safari browser app to display web content, and @c SKStoreProductViewController
     to display App Store links.
     */
    OSGDisplayAgentTypeNativeSafari,

    /**
     This exists for historical reason, and it behaves the same as @c OSGDisplayAgentTypeInApp.
     */
    OSGDisplayAgentTypeSafariViewController __attribute__((deprecated))
};
