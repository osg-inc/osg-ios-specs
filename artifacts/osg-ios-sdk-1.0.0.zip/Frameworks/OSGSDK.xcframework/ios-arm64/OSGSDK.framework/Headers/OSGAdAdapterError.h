//
//  OSGAdAdapterError.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString * const OSGAdAdapterErrorDomain;

// The raw values of this enum is the same as the deprecated `OSGRewardedAdsErrorCode` to be backward compatible.
typedef NS_ENUM(NSInteger, OSGAdAdapterErrorCode) {
    OSGAdAdapterErrorCodeUnknown = -1,
    OSGAdAdapterErrorCodeNoAdsAvailable = -1100,
    OSGAdAdapterErrorCodeInvalidAdapter = -1200,
    OSGAdAdapterErrorCodeNoAdReady = -1401,
    OSGAdAdapterErrorCodeInvalidAdUnitID = -1500,
    OSGAdAdapterErrorCodeInvalidReward = -1600,
    OSGAdAdapterErrorCodeNoRewardSelected = -1601,
};

@interface NSError (OSGAdAdapterError)

+ (NSError *)errorWithAdAdapterErrorCode:(OSGAdAdapterErrorCode)code;

+ (NSError *)errorWithAdAdapterErrorCode:(OSGAdAdapterErrorCode)code userInfo:(NSDictionary *)userInfo;

@end

NS_ASSUME_NONNULL_END
