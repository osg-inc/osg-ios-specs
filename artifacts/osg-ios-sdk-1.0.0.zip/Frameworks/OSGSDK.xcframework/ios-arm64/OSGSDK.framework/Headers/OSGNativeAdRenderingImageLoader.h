//
//  OSGNativeAdRenderingImageLoader.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <UIKit/UIKit.h>

@class OSGNativeAdRendererImageHandler;

@interface OSGNativeAdRenderingImageLoader : NSObject

- (instancetype)initWithImageHandler:(OSGNativeAdRendererImageHandler *)imageHandler;

- (void)loadImageForURL:(NSURL *)url intoImageView:(UIImageView *)imageView;

@end
