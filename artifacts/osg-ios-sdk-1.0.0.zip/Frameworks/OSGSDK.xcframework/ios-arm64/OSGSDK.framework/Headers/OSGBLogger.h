//
//  OSGBLogger.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import "OSGBLogLevel.h"

/**
 Objects which are capable of consuming log messages.
 */
@protocol OSGBLogger <NSObject>

/**
 Current logging level.
 */
@property (nonatomic, readonly) OSGBLogLevel logLevel;

/**
 Message to be logged.
 @param message Message to be logged.
 */
- (void)logMessage:(NSString * _Nullable)message;

@end
