//
//  OSGNativeAdRendererImageHandler.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OSGImageLoader.h"

@protocol OSGNativeAdRendererImageHandlerDelegate <OSGImageLoaderDelegate>
@end

@interface OSGNativeAdRendererImageHandler : OSGImageLoader

@property (nonatomic, weak) id<OSGNativeAdRendererImageHandlerDelegate> delegate;

@end
