//
//  OSGCollectionViewAdPlacerDelegate.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import "OSGAdPlacer.h"

@class OSGCollectionViewAdPlacer;

@protocol OSGCollectionViewAdPlacerDelegate <OSGAdPlacerDelegate>

@optional

/*
 This method is called when a native ad, placed by the collection view ad placer, will present a modal view controller.

 @param placer The collection view ad placer that contains the ad displaying the modal.
 */
- (void)nativeAdWillPresentModalForCollectionViewAdPlacer:(OSGCollectionViewAdPlacer *)placer;

/*
 This method is called when a native ad, placed by the collection view ad placer, did dismiss its modal view controller.

 @param placer The collection view ad placer that contains the ad that dismissed the modal.
 */
- (void)nativeAdDidDismissModalForCollectionViewAdPlacer:(OSGCollectionViewAdPlacer *)placer;

/*
 This method is called when a native ad, placed by the collection view ad placer, will cause the app to background due to user interaction with the ad.

 @param placer The collection view ad placer that contains the ad causing the app to background.
 */
- (void)nativeAdWillLeaveApplicationFromCollectionViewAdPlacer:(OSGCollectionViewAdPlacer *)placer;

@end
