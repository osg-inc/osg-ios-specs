//
//  OSGImageLoader.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class OSGImageLoader;

@protocol OSGImageLoaderDelegate <NSObject>

- (BOOL)nativeAdViewInViewHierarchy;

@optional

- (void)imageLoader:(OSGImageLoader *)imageLoader didLoadImageIntoImageView:(UIImageView *)imageView;

- (void)imageLoaderDidFailToLoadImageWithError:(NSError *)error;

@end

@interface OSGImageLoader : NSObject

@property (nonatomic, weak) id<OSGImageLoaderDelegate> delegate;

- (void)loadImageForURL:(NSURL *)imageURL intoImageView:(UIImageView *)imageView;

@end
