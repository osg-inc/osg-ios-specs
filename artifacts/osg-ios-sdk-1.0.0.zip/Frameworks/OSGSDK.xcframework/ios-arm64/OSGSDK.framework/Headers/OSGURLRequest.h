//
//  OSGURLRequest.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@interface OSGURLRequest : NSMutableURLRequest

/**
 Initializes an URL request with a given URL.
 @param URL The URL for the request.
 @returns Returns a URL request for a specified URL with @c NSURLRequestReloadIgnoringCacheData
 cache policy and @c kRequestTimeoutInterval timeout value.
 */
- (instancetype)initWithURL:(NSURL *)URL;

/**
 Initializes an URL request with a given URL.
 @param URL The URL for the request.
 @returns Returns a URL request for a specified URL with @c NSURLRequestReloadIgnoringCacheData
 cache policy and @c kRequestTimeoutInterval timeout value.
 */
+ (OSGURLRequest *)requestWithURL:(NSURL *)URL;

@end
NS_ASSUME_NONNULL_END
