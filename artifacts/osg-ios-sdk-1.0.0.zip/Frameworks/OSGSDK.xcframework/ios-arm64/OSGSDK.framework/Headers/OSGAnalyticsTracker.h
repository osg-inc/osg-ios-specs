//
//  OSGAnalyticsTracker.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>

@class OSGAdConfiguration;
@class OSGVASTTrackingEvent;

@protocol OSGAnalyticsTracker <NSObject>

/**
 Fires all impression tracking URLs associated with @c configuration and tracks
 @c SKAdNetwork @c startImpression on the given @c configuration object.
 @param configuration the ad configuration from which to track the impression metrics
 */
- (void)trackImpressionForConfiguration:(OSGAdConfiguration *)configuration;

/**
 Fires all click tracking URLs associated with @c configuration.
 @param configuration the ad configuration from which to track the click metrics
 */
- (void)trackClickForConfiguration:(OSGAdConfiguration *)configuration;

/**
 Fires-and-forgets an array of URLs.
 @c URLs the array of URLs to send requests to.
 */
- (void)sendTrackingRequestForURLs:(NSArray<NSURL *> *)URLs;

/**
 Tracks @c SKAdNetwork @c endImpression for the given @c configuration.
 @param configuration the ad configuration from which to track the impression metrics
 */
- (void)trackEndImpressionForConfiguration:(OSGAdConfiguration *)configuration;

/**
 Tracks @c SKAdNetwork @c startImpression for the given @c configuration. Does
 not track impression URLs! Note that @c trackImpressionForConfiguration calls
 @c trackSKAdNetworkStartImpressionForConfiguration automatically, so calling
 this manually after calling @c trackImpressionForConfiguration is redundant
 and possibly unwanted.
 @param configuration the ad configuration from which to track the impression metrics
 */
- (void)trackSKAdNetworkStartImpressionForConfiguration:(OSGAdConfiguration *)configuration;

@end

@interface OSGAnalyticsTracker : NSObject

+ (OSGAnalyticsTracker *)sharedTracker;

@end

@interface OSGAnalyticsTracker (OSGAnalyticsTracker) <OSGAnalyticsTracker>
@end
