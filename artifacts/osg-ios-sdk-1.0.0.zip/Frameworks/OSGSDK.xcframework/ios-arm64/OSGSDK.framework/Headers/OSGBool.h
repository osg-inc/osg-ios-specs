//
//  OSGBool.h
//
//  Copyright 2025-2026 OSG, Inc.
//

/**
 Tri-state boolean.
 */
typedef NS_ENUM(NSInteger, OSGBool) {
    /**
     No
     */
    OSGBoolNo = -1,

    /**
     Unknown
     */
    OSGBoolUnknown = 0,

    /**
     Yes
     */
    OSGBoolYes = 1,
};
