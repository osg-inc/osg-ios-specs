//
//  OSGDiskLRUCache.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import "OSGMediaFileCache.h"

@protocol OSGDiskLRUCache <NSObject>

/*
 Do NOT call any of the following methods on the main thread, potentially lengthy wait for disk IO
 */
- (BOOL)cachedDataExistsForKey:(NSString *)key;
- (NSData *)retrieveDataForKey:(NSString *)key;
- (void)storeData:(NSData *)data forKey:(NSString *)key;
- (void)removeAllCachedFiles;

@end

@interface OSGDiskLRUCache : NSObject

+ (OSGDiskLRUCache *)sharedDiskCache;

@end

@interface OSGDiskLRUCache (OSGDiskLRUCache) <OSGDiskLRUCache>
@end

@interface OSGDiskLRUCache (OSGMediaFileCache) <OSGMediaFileCache>
@end
