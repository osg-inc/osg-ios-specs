//
//  OSGBaseNativeAdRenderer.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface OSGBaseNativeAdRenderer : NSObject

@end

NS_ASSUME_NONNULL_END
