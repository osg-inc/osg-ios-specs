//
//  OSGNativeView.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <UIKit/UIKit.h>

@protocol OSGNativeViewDelegate;

@interface OSGNativeView : UIView

@property (nonatomic, weak) id<OSGNativeViewDelegate> delegate;

@end

@protocol OSGNativeViewDelegate <NSObject>

@required

- (void)nativeViewWillMoveToSuperview:(UIView *)superview;

@end
