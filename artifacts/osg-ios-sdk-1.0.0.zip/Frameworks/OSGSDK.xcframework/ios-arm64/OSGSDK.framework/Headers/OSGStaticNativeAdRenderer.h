//
//  OSGStaticNativeAdRenderer.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import "OSGBaseNativeAdRenderer.h"
#import "OSGNativeAdRenderer.h"

@class OSGNativeAdRendererConfiguration;
@class OSGStaticNativeAdRendererSettings;

@interface OSGStaticNativeAdRenderer : OSGBaseNativeAdRenderer <OSGNativeAdRenderer>

@property (nonatomic, readonly) OSGNativeViewSizeHandler viewSizeHandler;

+ (OSGNativeAdRendererConfiguration *)rendererConfigurationWithRendererSettings:(id<OSGNativeAdRendererSettings>)rendererSettings;

+ (OSGNativeAdRendererConfiguration *)rendererConfigurationWithRendererSettings:(id<OSGNativeAdRendererSettings>)rendererSettings
                                               additionalSupportedCustomEvents:(NSArray *)additionalSupportedCustomEvents;

@end
