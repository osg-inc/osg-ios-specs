//
//  OSGAdPlacer.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import "OSGAd.h"
#import "OSGImpressionData.h"

NS_ASSUME_NONNULL_BEGIN

@protocol OSGAdPlacerDelegate;

/**
 This protocol defines functionality that is shared between all MoPub ad placers.
 */
@protocol OSGAdPlacer <NSObject>

@required
/**
 All MoPub ad placers have a delegate to call back when certain events occur.
 */
@property (nonatomic, weak, nullable) id<OSGAdPlacerDelegate> delegate;

@end

/**
 This protocol defines callback events shared between all MoPub ad placers.
 */
@protocol OSGAdPlacerDelegate <NSObject>

@optional
/**
 Called when an impression is fired on the @c OSGAdPlacer instance. Includes
 information about the impression if applicable.

 @param adPlacer The @c OSGAdPlacer instance that fired the impression
 @param ad The @c OSGAd instance that fired the impression
 @param impressionData Information about the impression, or @c nil if the server didn't return any information.
 */
- (void)mopubAdPlacer:(id<OSGAdPlacer>)adPlacer didTrackImpressionForAd:(id<OSGAd>)ad withImpressionData:(OSGImpressionData * _Nullable)impressionData;

@end

NS_ASSUME_NONNULL_END
