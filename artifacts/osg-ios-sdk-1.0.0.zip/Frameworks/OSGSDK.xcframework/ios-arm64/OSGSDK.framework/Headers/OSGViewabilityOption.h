//
//  OSGViewabilityOption.h
//
//  Copyright 2025-2026 OSG, Inc.
//

/**
 Available viewability options
 @remark Any changes made to this bitmask should also be reflected in `OSGViewabilityTracker`
 `+ (void)initialize` method.
 */
typedef NS_OPTIONS(NSInteger, OSGViewabilityOption) {
    OSGViewabilityOptionNone = 0,
    OSGViewabilityOptionIAS  = 1 << 0,
    OSGViewabilityOptionMoat = 1 << 1,
    OSGViewabilityOptionAll  = ((OSGViewabilityOptionMoat << 1) - 1)
};
