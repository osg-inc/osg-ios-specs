//
//  OSGNativeAdError.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, OSGNativeAdErrorCode) {
    OSGNativeAdErrorUnknown = -1,
    OSGNativeAdErrorHTTPError = -1000,
    OSGNativeAdErrorInvalidServerResponse = -1001,
    OSGNativeAdErrorNoInventory = -1002,
    OSGNativeAdErrorImageDownloadFailed = -1003,
    OSGNativeAdErrorAdUnitWarmingUp = -1004,
    OSGNativeAdErrorVASTParsingFailed = -1005,
    OSGNativeAdErrorContentDisplayError = -1100,
    OSGNativeAdErrorRenderError = -1200
};

extern NSString * const OSGNativeAdsSDKDomain;

NSError *OSGNativeAdNSErrorForInvalidAdServerResponse(NSString *reason);
NSError *OSGNativeAdNSErrorForAdUnitWarmingUp(void);
NSError *OSGNativeAdNSErrorForNoInventory(void);
NSError *OSGNativeAdNSErrorForNetworkConnectionError(void);
NSError *OSGNativeAdNSErrorForInvalidImageURL(void);
NSError *OSGNativeAdNSErrorForImageDownloadFailure(void);
NSError *OSGNativeAdNSErrorForContentDisplayErrorMissingRootController(void);
NSError *OSGNativeAdNSErrorForContentDisplayErrorInvalidURL(void);
NSError *OSGNativeAdNSErrorForVASTParsingFailure(void);
NSError *OSGNativeAdNSErrorForRenderValueTypeError(void);
