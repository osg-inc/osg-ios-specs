//
//  OSGReward.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>

/// A constant that indicates that no currency type was specified with the reward.
extern NSString *const kOSGRewardCurrencyTypeUnspecified;

/// A constant that indicates that no currency amount was specified with the reward.
extern NSInteger const kOSGRewardCurrencyAmountUnspecified;

/**
 `OSGReward` contains all the information needed to reward the user for playing a rewarded ad. The
 class provides a currency amount and currency type.
 */
@interface OSGReward : NSObject

/**
 The type of currency that should be rewarded to the user.
 
 An undefined currency type should be specified as `kOSGRewardCurrencyTypeUnspecified`.
 */
@property (nonatomic, readonly) NSString *currencyType;

/**
 The amount of currency to reward to the user.
 
 An undefined currency amount should be specified as `kOSGRewardCurrencyAmountUnspecified` wrapped as
 an NSNumber.
 */
@property (nonatomic, readonly) NSNumber *amount;

/**
 Initialize with an undefined currency type @c kOSGRewardCurrencyTypeUnspecified and the provided amount.
 
 @param amount The amount of currency the user is receiving.
 */
- (instancetype)initWithCurrencyAmount:(NSNumber *)amount;

/**
 Initialize with @c the currencyType and @c amount.
 
 @param currencyType The type of currency the user is receiving.
 @param amount The amount of currency the user is receiving.
 */
- (instancetype)initWithCurrencyType:(NSString *)currencyType amount:(NSNumber *)amount;

/**
 Return a reward with type @c kOSGRewardCurrencyTypeUnspecified and amout @c kOSGRewardCurrencyAmountUnspecified.
 Typically this "unspecified reward" is a placehold object that represents an expected but unknown reward.
 */
+ (instancetype)unspecifiedReward;

/**
 A helper for comparing @c currencyType against @c kOSGRewardCurrencyTypeUnspecified.
 */
- (BOOL)isCurrencyTypeSpecified;

@end
