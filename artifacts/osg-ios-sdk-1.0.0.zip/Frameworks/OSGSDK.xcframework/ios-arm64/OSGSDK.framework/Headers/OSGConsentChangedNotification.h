//
//  OSGConsentChangedNotification.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>

/**
 Notification fired whenever the current consent status has changed. The payload
 will be included in the @NSNotification.userInfo dictionary.
 */
extern NSString * const kOSGConsentChangedNotification;

/**
 The new consent state; represented as a @c OSGConsentStatus value wrapped
 in a @c NSNumber.
 */
extern NSString * const kMPConsentChangedInfoNewConsentStatusKey;

/**
 The previous consent state; represented as a @c OSGConsentStatus value wrapped
 in a @c NSNumber.
 */
extern NSString * const kMPConsentChangedInfoPreviousConsentStatusKey;

/**
 Boolean flag indicating that it is okay to collection any personally
 identifiable information; represented as a @c BOOL value wrapped in
 a @c NSNumber.
 */
extern NSString * const kMPConsentChangedInfoCanCollectPersonalInfoKey;
