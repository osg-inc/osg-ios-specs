//
//  OSGAdServerURLBuilder.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import "OSGAdTargeting.h"
#import "OSGURL.h"

@interface OSGAdServerURLBuilder : NSObject

/**
 Name of the engine using the MoPub SDK. This field is @c nil for platform native integrations.
 */
@property (class, nonatomic, copy) NSString *engineName;

/**
 Version of the engine using the MoPub SDK. This field is @c nil for platform native integrations.
 */
@property (class, nonatomic, copy) NSString *engineVersion;

/**
 应用 ID（v2 协议 @c appid 字段）。来自 @c OSGConfiguration。
 */
@property (class, nonatomic, copy) NSString *appId;

/**
 应用 Key（v2 协议 @c app_key 字段）。来自 @c OSGConfiguration。
 */
@property (class, nonatomic, copy) NSString *appKey;

/**
 测试模式（v2 协议 @c test 字段）。来自 @c OSGConfiguration。
 */
@property (class, nonatomic, assign) BOOL testMode;

/**
 Returns an NSURL object given NSURLComponents and a dictionary of query parameters/values
 */
+ (OSGURL *)URLWithComponents:(NSURLComponents *)components postData:(NSDictionary *)parameters;

@end

@interface OSGAdServerURLBuilder (Ad)

+ (OSGURL *)URLWithAdUnitID:(NSString *)adUnitID
                 targeting:(OSGAdTargeting *)targeting;

+ (OSGURL *)URLWithAdUnitID:(NSString *)adUnitID
                 targeting:(OSGAdTargeting *)targeting
             desiredAssets:(NSArray *)assets;

+ (OSGURL *)URLWithAdUnitID:(NSString *)adUnitID
                 targeting:(OSGAdTargeting *)targeting
             desiredAssets:(NSArray *)assets
                adSequence:(NSInteger)adSequence;

@end

@interface OSGAdServerURLBuilder (Open)

/**
 Constructs the conversion tracking URL using current consent state, SDK state, and @c appID parameter.
 @param appID The App ID to be included in the URL.
 @returns URL to the open endpoint configuring for conversion tracking.
 */
+ (OSGURL *)conversionTrackingURLForAppID:(NSString *)appID;

/**
 Constructs the session tracking URL using current consent state and SDK state.
 @returns URL to the open endpoint configuring for session tracking.
 */
+ (OSGURL *)sessionTrackingURL;

@end

@interface OSGAdServerURLBuilder (Consent)

/**
 Constructs the consent synchronization endpoint URL using the current consent manager
 state.
 @returns URL to the consent synchronization endpoint.
 */
+ (OSGURL *)consentSynchronizationUrl;

/**
 Constructs the URL to fetch the consent dialog using the current consent manager state.
 @returns URL to the consent dialog endpoint
 */
+ (OSGURL *)consentDialogURL;

@end

@interface OSGAdServerURLBuilder (Native)

/**
 Constructs the URL to fetch the native ad positions for the given ad unit ID.
 @param adUnitId Native ad unit ID to fetch positioning information.
 @return URL for the native position request if successful; otherwise @c nil.
 */
+ (OSGURL *)nativePositionUrlForAdUnitId:(NSString *)adUnitId;

@end

@interface OSGAdServerURLBuilder (Rewarded)

/**
 Appends additional reward information to the source rewarded completion.
 @param sourceUrl The source rewarded completion URL given by the server.
 @param customerId Optional customer ID to associate with the reward.
 @param rewardType Optional reward type to associate with the customer.
 Both @c rewardType and @c rewardAmount must be present in order for them to be added.
 @param rewardAmount Optional reward amount to associate with the reward type.
 Both @c rewardType and @c rewardAmount must be present in order for them to be added.
 @param adapterClassName Optional name of the adapter class used to render the rewarded ad.
 @param additionalData Optional additional data passed in by the publisher to be sent back to
 their reward server.
 @return Expanded URL if successful; otherwise @c nil.
 */
+ (OSGURL *)rewardedCompletionUrl:(NSString *)sourceUrl
                  withCustomerId:(NSString *)customerId
                      rewardType:(NSString *)rewardType
                    rewardAmount:(NSNumber *)rewardAmount
                adapterClassName:(NSString *)adapterClassName
                  additionalData:(NSString *)additionalData;

@end

@interface OSGAdServerURLBuilder (SKAdNetwork)

/**
 Constructs URL to synchronize enabled SKAdNetwork networks with ad server.
 @param skAdNetworkIds List of SKAdNetwork IDs enabled for this app. Must be nonnull, more than one network
 @return URL to synchronize SKAdNetwork IDs to ad server, or @c nil if requirements for @c skAdNetworkIds are not met
 */
+ (OSGURL *)skAdNetworkSynchronizationURLWithSkAdNetworkIds:(NSArray <NSString *> *)skAdNetworkIds;

@end
