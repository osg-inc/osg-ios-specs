//
//  OSGGlobal.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#ifndef OSG_ANIMATED
#define OSG_ANIMATED YES
#endif

UIInterfaceOrientation OSGInterfaceOrientation(void);
UIWindow *OSGKeyWindow(void);
CGFloat OSGStatusBarHeight(void);
CGRect OSGApplicationFrame(BOOL includeSafeAreaInsets);
CGRect OSGScreenBounds(void);
CGSize OSGScreenResolution(void);
CGFloat OSGDeviceScaleFactor(void);
NSDictionary *OSGDictionaryFromQueryString(NSString *query);
NSString *OSGSHA1Digest(NSString *string);
NSString *OSGResourcePathForResource(NSString *resourceName);
NSArray *OSGConvertStringArrayToURLArray(NSArray *strArray);

////////////////////////////////////////////////////////////////////////////////////////////////////

typedef NS_ENUM(NSUInteger, OSGInterstitialCloseButtonStyle) {
    OSGInterstitialCloseButtonStyleAlwaysVisible,
    OSGInterstitialCloseButtonStyleAlwaysHidden,
    OSGInterstitialCloseButtonStyleAdControlled,
} __deprecated_enum_msg("This is not used any more since 5.12.");

typedef NS_ENUM(NSUInteger, OSGInterstitialOrientationType) {
    OSGInterstitialOrientationTypePortrait,
    OSGInterstitialOrientationTypeLandscape,
    OSGInterstitialOrientationTypeAll,
};

UIInterfaceOrientationMask OSGInterstitialOrientationTypeToUIInterfaceOrientationMask(OSGInterstitialOrientationType type);

////////////////////////////////////////////////////////////////////////////////////////////////////

@interface UIDevice (OSGAdditions)

- (NSString *)osg_hardwareDeviceName;

@end

////////////////////////////////////////////////////////////////////////////////////////////////////

@interface UIApplication (OSGAdditions)

- (BOOL)osg_supportsOrientationMask:(UIInterfaceOrientationMask)orientationMask;
- (BOOL)osg_doesOrientation:(UIInterfaceOrientation)orientation matchOrientationMask:(UIInterfaceOrientationMask)orientationMask;

@end
