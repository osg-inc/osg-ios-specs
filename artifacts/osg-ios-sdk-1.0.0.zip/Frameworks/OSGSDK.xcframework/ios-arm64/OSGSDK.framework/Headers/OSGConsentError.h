//
//  OSGConsentError.h
//
//  Copyright 2025-2026 OSG, Inc.
//

static NSString * const kConsentErrorDomain = @"com.osg.osg-ios-sdk.consent";

/**
 Error codes related to consent management.
 */
typedef NS_ENUM(NSUInteger, OSGConsentErrorCode) {
    OSGConsentErrorCodeLimitAdTrackingEnabled = 1,
    OSGConsentErrorCodeFailedToParseSynchronizationResponse,
    OSGConsentErrorCodeGDPRIsNotApplicable,
};
