//
//  OSGImpressionTrackedNotification.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>

/**
 Notification fired when an impression is tracked. The adunit ID will always be
 included in the @c NSNotification.userData dictionary. If the server returned
 impression data, the @c OSGImpressionData object will be included in the
 @c NSNotification.userData dictionary. The sender can be determined by
 querying @c NSNotification.object.
 */
extern NSString * const kOSGImpressionTrackedNotification;

/**
 The @c OSGImpressionData object for the given impression, or @c nil if the server did not send
 impression data with this impression.
 */
extern NSString * const kOSGImpressionTrackedInfoImpressionDataKey;

/**
 The adunit ID associated with the impression.
 */
extern NSString * const kOSGImpressionTrackedInfoAdUnitIDKey;
