//
//  OSGVASTMediaFile.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OSGVASTModel.h"

@interface OSGVASTMediaFile : OSGVASTModel

@property (nonatomic, copy, readonly) NSString *identifier;
@property (nonatomic, copy, readonly) NSString *delivery;
@property (nonatomic, copy, readonly) NSString *mimeType;
@property (nonatomic, readonly) CGFloat bitrate;
@property (nonatomic, readonly) CGFloat width;
@property (nonatomic, readonly) CGFloat height;
@property (nonatomic, copy, readonly) NSURL *URL;

@end

@interface OSGVASTMediaFile (Selection)

/**
 Pick the best media file that fits into the provided container size and scale factor.
 */
+ (OSGVASTMediaFile *)bestMediaFileFromCandidates:(NSArray<OSGVASTMediaFile *> *)candidates
                                forContainerSize:(CGSize)containerSize
                            containerScaleFactor:(CGFloat)containerScaleFactor;

@end

@interface OSGVASTMediaFile (MimeType)

/**
 The file extension associated with this VAST MIME type. In the event that the VAST MIME type is
 invalid, this will be @c nil.
 */
@property (nonatomic, copy, readonly) NSString *fileExtensionForMimeType;

@end
