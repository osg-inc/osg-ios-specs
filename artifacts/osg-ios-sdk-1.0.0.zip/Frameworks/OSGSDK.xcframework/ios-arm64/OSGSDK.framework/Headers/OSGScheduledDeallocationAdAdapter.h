//
//  OSGScheduledDeallocationAdAdapter.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Protocol for rendering adapters that require scheduled deallocation via @c OSGViewabilityManager.
 */
@protocol OSGScheduledDeallocationAdAdapter <NSObject>

/**
 Ends the Viewability session for this adapter.
 */
- (void)stopViewabilitySession;

@end

NS_ASSUME_NONNULL_END
