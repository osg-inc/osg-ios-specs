//
//  OSGConsentStatus.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>

/**
 Personally identifiable information (PII) consent status.
 PII is allowed to be collected only if @c OSGConsentStatus is @c OSGConsentStatusConsented.
 In all other cases, PII is not allowed to be collected.
 */
typedef NS_ENUM(NSInteger, OSGConsentStatus) {
    /**
     Status is unknown. Either the status is currently updating or
     @c initializeSdkWithConfiguration:completion: has not been called.
     */
    OSGConsentStatusUnknown = 0,

    /**
     Consent is denied.
     */
    OSGConsentStatusDenied,

    /**
     Advertiser tracking is disabled.
     */
    OSGConsentStatusDoNotTrack,

    /**
     A potentially whitelisted publisher has attempted to grant consent on
     the user's behalf.
     */
    OSGConsentStatusPotentialWhitelist,

    /**
     Consented.
     */
    OSGConsentStatusConsented
};
