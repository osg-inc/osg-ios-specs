//
//  OSGAppLovinMediationAdapter.h
//  osg-ios-applovin-mediation-adapter
//

#import <AppLovinSDK/AppLovinSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface OSGAppLovinMediationAdapter : ALMediationAdapter <MAAdViewAdapter, MAInterstitialAdapter, MARewardedAdapter, MANativeAdAdapter>

@end

NS_ASSUME_NONNULL_END
