//
//  OSGAppLovinMediationConstants.h
//  osg-ios-applovin-mediation-adapter
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// MAX Custom Network credentials keys (configure in AppLovin dashboard).
FOUNDATION_EXPORT NSString * const kOSGAppLovinMediationAdUnitIdKey;
FOUNDATION_EXPORT NSString * const kOSGAppLovinMediationAppIdKey;
FOUNDATION_EXPORT NSString * const kOSGAppLovinMediationAppKeyKey;
FOUNDATION_EXPORT NSString * const kOSGAppLovinMediationTestModeKey;

FOUNDATION_EXPORT NSString * const kOSGAppLovinMediationAdapterVersion;

NS_ASSUME_NONNULL_END
