//
//  OSGAppLovinMediationNativeAd.h
//  osg-ios-applovin-mediation-adapter
//

#import <AppLovinSDK/AppLovinSDK.h>

@class OSGNativeAd;

NS_ASSUME_NONNULL_BEGIN

@interface OSGAppLovinMediationNativeAd : MANativeAd

@property (nonatomic, strong, readonly) OSGNativeAd *osgNativeAd;

- (instancetype)initWithOSGNativeAd:(OSGNativeAd *)nativeAd
                        mediaView:(UIView *)mediaView
                       properties:(NSDictionary *)properties;

@end

NS_ASSUME_NONNULL_END
