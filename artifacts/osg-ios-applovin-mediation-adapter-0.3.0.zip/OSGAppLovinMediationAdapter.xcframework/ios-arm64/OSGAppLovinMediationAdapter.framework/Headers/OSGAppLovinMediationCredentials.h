//
//  OSGAppLovinMediationCredentials.h
//  osg-ios-applovin-mediation-adapter
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface OSGAppLovinMediationCredentials : NSObject

@property (nonatomic, copy, readonly) NSString *adUnitId;
@property (nonatomic, copy, readonly, nullable) NSString *appId;
@property (nonatomic, copy, readonly, nullable) NSString *appKey;
@property (nonatomic, assign, readonly) BOOL testMode;

- (instancetype)initWithServerParameters:(NSDictionary<NSString *, id> *)serverParameters;
- (nullable NSError *)validationError;

@end

NS_ASSUME_NONNULL_END
