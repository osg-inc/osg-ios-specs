//
//  OSGNativeAdRequest.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>

@class OSGNativeAd;
@class OSGNativeAdRequest;
@class OSGNativeAdRequestTargeting;

typedef void(^OSGNativeAdRequestHandler)(OSGNativeAdRequest *request,
                                      OSGNativeAd *response,
                                      NSError *error);

////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 The `OSGNativeAdRequest` class is used to manage individual requests to the OSG ad server for
 native ads.

 @warning **Note:** This class is meant for one-off requests for which you intend to manually
 process the native ad response. If you are using `OSGTableViewAdPlacer` or
 `OSGCollectionViewAdPlacer` to display ads, there should be no need for you to use this class.
 */

@interface OSGNativeAdRequest : NSObject

/** @name Targeting Information */

/**
 An object representing targeting parameters that can be passed to the OSG ad server to
 serve more relevant advertising.
 */
@property (nonatomic, strong) OSGNativeAdRequestTargeting *targeting;

/** @name Initializing and Starting an Ad Request */

/**
 Initializes a request object.

 @param identifier The ad unit identifier for this request. An ad unit is a defined placement in
 your application set aside for advertising. Ad unit IDs are created on the OSG dashboard.

 @param rendererConfigurations An array of OSGNativeAdRendererConfiguration objects that control how
 the native ad is rendered.

 @return An `OSGNativeAdRequest` object.
 */
+ (OSGNativeAdRequest *)requestWithAdUnitIdentifier:(NSString *)identifier rendererConfigurations:(NSArray *)rendererConfigurations;

/**
 Executes a request to the OSG ad server.

 @param handler A block to execute when the request finishes. The block includes as parameters the
 request itself and either a valid OSGNativeAd or an NSError object indicating failure.
 */
- (void)startWithCompletionHandler:(OSGNativeAdRequestHandler)handler;

@end
