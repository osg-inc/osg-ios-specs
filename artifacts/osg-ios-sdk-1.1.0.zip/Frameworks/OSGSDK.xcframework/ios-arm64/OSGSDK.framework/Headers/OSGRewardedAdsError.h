//
//  OSGRewardedAdsError.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>

typedef enum {
    OSGRewardedAdErrorUnknown = -1,
    OSGRewardedAdErrorTimeout = -1000,
    OSGRewardedAdErrorAdUnitWarmingUp = -1001,
    OSGRewardedAdErrorNoAdsAvailable = -1100,
    OSGRewardedAdErrorInvalidCustomEvent = -1200,
    OSGRewardedAdErrorMismatchingAdTypes = -1300,
    OSGRewardedAdErrorAdAlreadyPlayed = -1400,
    OSGRewardedAdErrorNoAdReady = -1401,
    OSGRewardedAdErrorInvalidAdUnitID = -1500,
    OSGRewardedAdErrorInvalidReward = -1600,
    OSGRewardedAdErrorNoRewardSelected = -1601,
} OSGRewardedAdsErrorCode;

extern NSString * const OSGRewardedAdsErrorDomain;
