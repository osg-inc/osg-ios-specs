//
//  OSGNativeCustomEventDelegate.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>

@class OSGNativeAd;
@class OSGNativeCustomEvent;

/**
 Instances of your custom subclass of `OSGNativeCustomEvent` will have an
 `OSGNativeCustomEventDelegate` delegate object. You use this delegate to communicate progress
 (such as whether an ad has loaded successfully) back to the OSG SDK.
 */
@protocol OSGNativeCustomEventDelegate <NSObject>

/**
 This method is called when the ad and all required ad assets are loaded.

 @param event You should pass `self` to allow the OSG SDK to associate this event with the
 correct instance of your custom event.
 @param adObject An `OSGNativeAd` object, representing the ad that was retrieved.
 */
- (void)nativeCustomEvent:(OSGNativeCustomEvent *)event didLoadAd:(OSGNativeAd *)adObject;

/**
 This method is called when the ad or any required ad assets fail to load.

 @param event You should pass `self` to allow the OSG SDK to associate this event with the
 correct instance of your custom event.
 @param error (*optional*) You may pass an error describing the failure.
 */
- (void)nativeCustomEvent:(OSGNativeCustomEvent *)event didFailToLoadAdWithError:(NSError *)error;

@end
