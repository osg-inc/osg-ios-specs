//
//  OSGRewardedVideo.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OSGImpressionData.h"

@class OSGReward;
@class OSGRewardedVideoReward;
@class CLLocation;
@protocol OSGRewardedVideoDelegate;

/**
 Notice:
 @c OSGRewardedVideo is deprecated and will be removed in a future version. Use
 @c OSGRewardedAds instead.

 @c OSGRewardedVideo allows you to load and play rewarded video ads. All ad events are
 reported, with an ad unit ID, to the delegate allowing the application to respond to the events
 for the corresponding ad.
 */
DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo is deprecated. Please use OSGRewardedAds instead.")
@interface OSGRewardedVideo : NSObject

/**
 Sets the delegate that will be the receiver of rewarded video events for the given
 ad unit ID.
 @remark A weak reference to the delegate will be held.
 @deprecated This API is deprecated and will be removed in a future version.
 @param delegate Delegate that will recieve rewarded video events for the ad unit ID.
 @param adUnitId Ad unit ID
 */
+ (void)setDelegate:(id<OSGRewardedVideoDelegate>)delegate forAdUnitId:(NSString *)adUnitId DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo.setDelegate:forAdUnitId: is deprecated and will be removed in a future version. Use OSGRewardedAds.setDelegate:forAdUnitId: instead.");

/**
 Removes the delegate as a receiver of rewarded video events for all available ad unit IDs.
 @deprecated This API is deprecated and will be removed in a future version.
 @param delegate Reference to the delegate to remove as a listener.
 */
+ (void)removeDelegate:(id<OSGRewardedVideoDelegate>)delegate DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo.removeDelegate: is deprecated and will be removed in a future version. Use OSGRewardedAds.removeDelegate: instead.");

/**
 Removes the rewarded video delegate that is associated with the ad unit ID.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitId Ad unit ID of the delegate to remove.
 */
+ (void)removeDelegateForAdUnitId:(NSString *)adUnitId DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo.removeDelegateForAdUnitId: is deprecated and will be removed in a future version. Use OSGRewardedAds.removeDelegateForAdUnitId: instead.");

/**
 Loads a rewarded video ad for the given ad unit ID.
 The mediation settings array should contain ad network specific objects for networks that may be loaded for the given ad unit ID.
 You should set the properties on these objects to determine how the underlying ad network should behave. You only need to supply
 objects for the networks you wish to configure. If you do not want your network to behave differently from its default behavior, do
 not pass in an mediation settings object for that network.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID that ads should be loaded from.
 @param mediationSettings An array of mediation settings objects that map to networks that may show ads for the ad unit ID. This array
 should only contain objects for networks you wish to configure. This can be nil.
 */
+ (void)loadRewardedVideoAdWithAdUnitID:(NSString *)adUnitID withMediationSettings:(NSArray *)mediationSettings DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo.loadRewardedVideoAdWithAdUnitID:withMediationSettings: is deprecated and will be removed in a future version. Use OSGRewardedAds.loadRewardedAdWithAdUnitID:withMediationSettings: instead.");

/**
 Loads a rewarded video ad for the given ad unit ID.
 The mediation settings array should contain ad network specific objects for networks that may be loaded for the given ad unit ID.
 You should set the properties on these objects to determine how the underlying ad network should behave. You only need to supply
 objects for the networks you wish to configure. If you do not want your network to behave differently from its default behavior, do
 not pass in an mediation settings object for that network.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID that ads should be loaded from.
 @param keywords A string representing a set of non-personally identifiable keywords that should be passed to the OSG ad server to receive more relevant advertising.
 @param userDataKeywords A string representing a set of personally identifiable keywords that should be passed to the OSG ad server to receive
 more relevant advertising.
 @param mediationSettings An array of mediation settings objects that map to networks that may show ads for the ad unit ID. This array
 should only contain objects for networks you wish to configure. This can be nil.
 Note: If a user is in General Data Protection Regulation (GDPR) region and OSG doesn't obtain consent from the user, "keywords" will be sent to the server but "userDataKeywords" will be excluded.
 */
+ (void)loadRewardedVideoAdWithAdUnitID:(NSString *)adUnitID keywords:(NSString *)keywords userDataKeywords:(NSString *)userDataKeywords mediationSettings:(NSArray *)mediationSettings DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo.loadRewardedVideoAdWithAdUnitID:keywords:userDataKeywords:mediationSettings: is deprecated and will be removed in a future version. Use OSGRewardedAds.loadRewardedAdWithAdUnitID:keywords:userDataKeywords:mediationSettings: instead.");

/**
 Loads a rewarded video ad for the given ad unit ID.
 The mediation settings array should contain ad network specific objects for networks that may be loaded for the given ad unit ID.
 You should set the properties on these objects to determine how the underlying ad network should behave. You only need to supply
 objects for the networks you wish to configure. If you do not want your network to behave differently from its default behavior, do
 not pass in an mediation settings object for that network.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID that ads should be loaded from.
 @param keywords A string representing a set of non-personally identifiable keywords that should be passed to the OSG ad server to receive more relevant advertising.
 @param userDataKeywords A string representing a set of personally identifiable keywords that should be passed to the OSG ad server to receive
 more relevant advertising.
 @param location Latitude/Longitude that are passed to the OSG ad server
 @param mediationSettings An array of mediation settings objects that map to networks that may show ads for the ad unit ID. This array
 should only contain objects for networks you wish to configure. This can be nil.
 Note: If a user is in General Data Protection Regulation (GDPR) region and OSG doesn't obtain consent from the user, "keywords" will be sent to the server but "userDataKeywords" will be excluded.
 */
+ (void)loadRewardedVideoAdWithAdUnitID:(NSString *)adUnitID keywords:(NSString *)keywords userDataKeywords:(NSString *)userDataKeywords location:(CLLocation *)location mediationSettings:(NSArray *)mediationSettings DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo.loadRewardedVideoAdWithAdUnitID:keywords:userDataKeywords:location:mediationSettings: is deprecated and will be removed in a future version. Use OSGRewardedAds.loadRewardedAdWithAdUnitID:keywords:userDataKeywords:mediationSettings: instead.");

/**
 Loads a rewarded video ad for the given ad unit ID.
 The mediation settings array should contain ad network specific objects for networks that may be loaded for the given ad unit ID.
 You should set the properties on these objects to determine how the underlying ad network should behave. You only need to supply
 objects for the networks you wish to configure. If you do not want your network to behave differently from its default behavior, do
 not pass in an mediation settings object for that network.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID that ads should be loaded from.
 @param keywords A string representing a set of non-personally identifiable keywords that should be passed to the OSG ad server to receive more relevant advertising.
 @param userDataKeywords A string representing a set of personally identifiable keywords that should be passed to the OSG ad server to receive
 more relevant advertising.
 @param customerId This is the ID given to the user by the publisher to identify them in their app
 @param mediationSettings An array of mediation settings objects that map to networks that may show ads for the ad unit ID. This array
 should only contain objects for networks you wish to configure. This can be nil.
 Note: If a user is in General Data Protection Regulation (GDPR) region and OSG doesn't obtain consent from the user, "keywords" will be sent to the server but "userDataKeywords" will be excluded.
 */
+ (void)loadRewardedVideoAdWithAdUnitID:(NSString *)adUnitID keywords:(NSString *)keywords userDataKeywords:(NSString *)userDataKeywords customerId:(NSString *)customerId mediationSettings:(NSArray *)mediationSettings DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo.loadRewardedVideoAdWithAdUnitID:keywords:userDataKeywords:customerId:mediationSettings: is deprecated and will be removed in a future version. Use OSGRewardedAds.loadRewardedAdWithAdUnitID:keywords:userDataKeywords:customerId:mediationSettings: instead.");

/**
 Loads a rewarded video ad for the given ad unit ID.
 The mediation settings array should contain ad network specific objects for networks that may be loaded for the given ad unit ID.
 You should set the properties on these objects to determine how the underlying ad network should behave. You only need to supply
 objects for the networks you wish to configure. If you do not want your network to behave differently from its default behavior, do
 not pass in an mediation settings object for that network.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID that ads should be loaded from.
 @param keywords A string representing a set of non-personally identifiable keywords that should be passed to the OSG ad server to receive more relevant advertising.
 @param userDataKeywords A string representing a set of personally identifiable keywords that should be passed to the OSG ad server to receive
 more relevant advertising.
 @param location Latitude/Longitude that are passed to the OSG ad server
 @param customerId This is the ID given to the user by the publisher to identify them in their app
 @param mediationSettings An array of mediation settings objects that map to networks that may show ads for the ad unit ID. This array
 should only contain objects for networks you wish to configure. This can be nil.
 Note: If a user is in General Data Protection Regulation (GDPR) region and OSG doesn't obtain consent from the user, "keywords" will be sent to the server but "userDataKeywords" will be excluded.
 */
+ (void)loadRewardedVideoAdWithAdUnitID:(NSString *)adUnitID keywords:(NSString *)keywords userDataKeywords:(NSString *)userDataKeywords location:(CLLocation *)location customerId:(NSString *)customerId mediationSettings:(NSArray *)mediationSettings DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo.loadRewardedVideoAdWithAdUnitID:keywords:userDataKeywords:location:customerId:mediationSettings: is deprecated and will be removed in a future version. Use OSGRewardedAds.loadRewardedAdWithAdUnitID:keywords:userDataKeywords:customerId:mediationSettings: instead.");

/**
 Loads a rewarded video ad for the given ad unit ID.
 The mediation settings array should contain ad network specific objects for networks that may be loaded for the given ad unit ID.
 You should set the properties on these objects to determine how the underlying ad network should behave. You only need to supply
 objects for the networks you wish to configure. If you do not want your network to behave differently from its default behavior, do
 not pass in an mediation settings object for that network.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID that ads should be loaded from.
 @param keywords A string representing a set of non-personally identifiable keywords that should be passed to the OSG ad server to receive more relevant advertising.
 @param userDataKeywords A string representing a set of personally identifiable keywords that should be passed to the OSG ad server to receive
 more relevant advertising.
 @param customerId This is the ID given to the user by the publisher to identify them in their app
 @param mediationSettings An array of mediation settings objects that map to networks that may show ads for the ad unit ID. This array
 should only contain objects for networks you wish to configure. This can be nil.
 @param localExtras An optional dictionary containing extra local data.
 Note: If a user is in General Data Protection Regulation (GDPR) region and OSG doesn't obtain consent from the user, "keywords" will be sent to the server but "userDataKeywords" will be excluded.
 */
+ (void)loadRewardedVideoAdWithAdUnitID:(NSString *)adUnitID keywords:(NSString *)keywords userDataKeywords:(NSString *)userDataKeywords customerId:(NSString *)customerId mediationSettings:(NSArray *)mediationSettings localExtras:(NSDictionary *)localExtras DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo.loadRewardedVideoAdWithAdUnitID:keywords:userDataKeywords:customerId:mediationSettings:localExtras: is deprecated and will be removed in a future version. Use OSGRewardedAds.loadRewardedAdWithAdUnitID:keywords:userDataKeywords:customerId:mediationSettings:localExtras: instead.");

/**
 Loads a rewarded video ad for the given ad unit ID.
 The mediation settings array should contain ad network specific objects for networks that may be loaded for the given ad unit ID.
 You should set the properties on these objects to determine how the underlying ad network should behave. You only need to supply
 objects for the networks you wish to configure. If you do not want your network to behave differently from its default behavior, do
 not pass in an mediation settings object for that network.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID that ads should be loaded from.
 @param keywords A string representing a set of non-personally identifiable keywords that should be passed to the OSG ad server to receive more relevant advertising.
 @param userDataKeywords A string representing a set of personally identifiable keywords that should be passed to the OSG ad server to receive
 more relevant advertising.
 @param location Latitude/Longitude that are passed to the OSG ad server
 @param customerId This is the ID given to the user by the publisher to identify them in their app
 @param mediationSettings An array of mediation settings objects that map to networks that may show ads for the ad unit ID. This array
 should only contain objects for networks you wish to configure. This can be nil.
 @param localExtras An optional dictionary containing extra local data.
 Note: If a user is in General Data Protection Regulation (GDPR) region and OSG doesn't obtain consent from the user, "keywords" will be sent to the server but "userDataKeywords" will be excluded.
 */
+ (void)loadRewardedVideoAdWithAdUnitID:(NSString *)adUnitID keywords:(NSString *)keywords userDataKeywords:(NSString *)userDataKeywords location:(CLLocation *)location customerId:(NSString *)customerId mediationSettings:(NSArray *)mediationSettings localExtras:(NSDictionary *)localExtras DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo.loadRewardedVideoAdWithAdUnitID:keywords:userDataKeywords:location:customerId:mediationSettings:localExtras: is deprecated and will be removed in a future version. Use OSGRewardedAds.loadRewardedAdWithAdUnitID:keywords:userDataKeywords:customerId:mediationSettings:localExtras: instead.");

/**
 Returns whether or not an ad is available for the given ad unit ID.
 @param adUnitID The ad unit ID associated with the ad you want to retrieve the availability for.
 @deprecated This API is deprecated and will be removed in a future version.
 */
+ (BOOL)hasAdAvailableForAdUnitID:(NSString *)adUnitID DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo.hasAdAvailableForAdUnitID: is deprecated and will be removed in a future version. Use OSGRewardedAds.hasAdAvailableForAdUnitID: instead.");

/**
 Returns an array of @c OSGRewardedVideoReward that are available for the given ad unit ID.
 @deprecated This API is deprecated and will be removed in a future version.
 */
+ (NSArray *)availableRewardsForAdUnitID:(NSString *)adUnitID DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo.availableRewardsForAdUnitID: is deprecated and will be removed in a future version. Use OSGRewardedAds.availableRewardsForAdUnitID: instead.");

/**
 The currently selected reward that will be awarded to the user upon completion of the ad. By default,
 this corresponds to the first reward in `availableRewardsForAdUnitID:`.
 @deprecated This API is deprecated and will be removed in a future version.
 */
+ (OSGRewardedVideoReward *)selectedRewardForAdUnitID:(NSString *)adUnitID DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo.selectedRewardForAdUnitID: is deprecated and will be removed in a future version. Use OSGRewardedAds.selectedRewardForAdUnitID: instead.");

/**
 Plays a rewarded video ad.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID associated with the video ad you wish to play.
 @param viewController The view controller that will present the rewarded video ad.
 @param reward A reward selected from `availableRewardsForAdUnitID:` to award the user upon successful completion of the ad.
 This value should not be `nil`.
 @warning **Important**: You should not attempt to play the rewarded video unless `+hasAdAvailableForAdUnitID:` indicates that an
 ad is available for playing or you have received the `[-rewardedVideoAdDidLoadForAdUnitID:]([OSGRewardedVideoDelegate rewardedVideoAdDidLoadForAdUnitID:])`
 message.
 */
+ (void)presentRewardedVideoAdForAdUnitID:(NSString *)adUnitID fromViewController:(UIViewController *)viewController withReward:(OSGRewardedVideoReward *)reward DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo.presentRewardedVideoAdForAdUnitID:fromViewController:withReward: is deprecated and will be removed in a future version. Use OSGRewardedAds.presentRewardedAdForAdUnitID:fromViewController:withReward: instead.");

/**
 Plays a rewarded video ad.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID associated with the video ad you wish to play.
 @param viewController The view controller that will present the rewarded video ad.
 @param reward A reward selected from `availableRewardsForAdUnitID:` to award the user upon successful completion of the ad.
 This value should not be `nil`.
 @param customData Optional custom data string to include in the server-to-server callback. If a server-to-server callback
 is not used, or if the ad unit is configured for local rewarding, this value will not be persisted.
 @warning **Important**: You should not attempt to play the rewarded video unless `+hasAdAvailableForAdUnitID:` indicates that an
 ad is available for playing or you have received the `[-rewardedVideoAdDidLoadForAdUnitID:]([OSGRewardedVideoDelegate rewardedVideoAdDidLoadForAdUnitID:])`
 message.
 */
+ (void)presentRewardedVideoAdForAdUnitID:(NSString *)adUnitID fromViewController:(UIViewController *)viewController withReward:(OSGRewardedVideoReward *)reward customData:(NSString *)customData DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideo.presentRewardedVideoAdForAdUnitID:fromViewController:withReward:customData: is deprecated and will be removed in a future version. Use OSGRewardedAds.presentRewardedAdForAdUnitID:fromViewController:withReward:customData: instead.");

@end

@protocol OSGRewardedVideoDelegate <NSObject>

@optional

/**
 This method is called after an ad loads successfully.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID of the ad associated with the event.
 */
- (void)rewardedVideoAdDidLoadForAdUnitID:(NSString *)adUnitID DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoDelegate.rewardedVideoAdDidLoadForAdUnitID: is deprecated and will be removed in a future version. Use OSGRewardedAdsDelegate.rewardedAdDidLoadForAdUnitID: instead.");

/**
 This method is called after an ad fails to load.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID of the ad associated with the event.
 @param error An error indicating why the ad failed to load.
 */
- (void)rewardedVideoAdDidFailToLoadForAdUnitID:(NSString *)adUnitID error:(NSError *)error DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoDelegate.rewardedVideoAdDidFailToLoadForAdUnitID:error: is deprecated and will be removed in a future version. Use OSGRewardedAdsDelegate.rewardedAdDidFailToLoadForAdUnitID:error: instead.");

/**
 This method is called when a previously loaded rewarded video is no longer eligible for presentation.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID of the ad associated with the event.
 */
- (void)rewardedVideoAdDidExpireForAdUnitID:(NSString *)adUnitID DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoDelegate.rewardedVideoAdDidExpireForAdUnitID: is deprecated and will be removed in a future version. Use OSGRewardedAdsDelegate.rewardedAdDidExpireForAdUnitID: instead.");

/**
 This method is called when an attempt to play a rewarded video fails.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID of the ad associated with the event.
 @param error An error describing why the video couldn't play.
 */
- (void)rewardedVideoAdDidFailToPlayForAdUnitID:(NSString *)adUnitID error:(NSError *)error DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoDelegate.rewardedVideoAdDidFailToPlayForAdUnitID:error: is deprecated and will be removed in a future version. Use OSGRewardedAdsDelegate.rewardedAdDidFailToShowForAdUnitID:error: instead.");

/**
 This method is called when a rewarded video ad is about to appear.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID of the ad associated with the event.
 */
- (void)rewardedVideoAdWillAppearForAdUnitID:(NSString *)adUnitID DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoDelegate.rewardedVideoAdWillAppearForAdUnitID: is deprecated and will be removed in a future version. Use OSGRewardedAdsDelegate.rewardedAdWillPresentForAdUnitID: instead.");

/**
 This method is called when a rewarded video ad has appeared.
 Your implementation of this method should pause any application activity that requires user
 interaction.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID of the ad associated with the event.
 */
- (void)rewardedVideoAdDidAppearForAdUnitID:(NSString *)adUnitID DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoDelegate.rewardedVideoAdDidAppearForAdUnitID: is deprecated and will be removed in a future version. Use OSGRewardedAdsDelegate.rewardedAdDidPresentForAdUnitID: instead.");

/**
 This method is called when a rewarded video ad will be dismissed.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID of the ad associated with the event.
 */
- (void)rewardedVideoAdWillDisappearForAdUnitID:(NSString *)adUnitID DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoDelegate.rewardedVideoAdWillDisappearForAdUnitID: is deprecated and will be removed in a future version. Use OSGRewardedAdsDelegate.rewardedAdWillDismissForAdUnitID: instead.");

/**
 This method is called when a rewarded video ad has been dismissed.
 Your implementation of this method should resume any application activity that was paused
 prior to the interstitial being presented on-screen.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID of the ad associated with the event.
 */
- (void)rewardedVideoAdDidDisappearForAdUnitID:(NSString *)adUnitID DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoDelegate.rewardedVideoAdDidDisappearForAdUnitID: is deprecated and will be removed in a future version. Use OSGRewardedAdsDelegate.rewardedAdDidDismissForAdUnitID: instead.");

/**
 This method is called when the user taps on the ad.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID of the ad associated with the event.
 */
- (void)rewardedVideoAdDidReceiveTapEventForAdUnitID:(NSString *)adUnitID DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoDelegate.rewardedVideoAdDidReceiveTapEventForAdUnitID: is deprecated and will be removed in a future version. Use OSGRewardedAdsDelegate.rewardedAdDidReceiveTapEventForAdUnitID: instead.");

/**
 This method is called when a rewarded video ad will cause the user to leave the application.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID of the ad associated with the event.
 */
- (void)rewardedVideoAdWillLeaveApplicationForAdUnitID:(NSString *)adUnitID DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoDelegate.rewardedVideoAdWillLeaveApplicationForAdUnitID: is deprecated and will be removed in a future version. Use OSGRewardedAdsDelegate.rewardedAdWillLeaveApplicationForAdUnitID: instead.");

/**
 This method is called when the user should be rewarded for watching a rewarded video ad.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID of the ad associated with the event.
 @param reward The object that contains all the information regarding how much you should reward the user.
 */
- (void)rewardedVideoAdShouldRewardForAdUnitID:(NSString *)adUnitID reward:(OSGRewardedVideoReward *)reward DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoDelegate.rewardedVideoAdShouldRewardForAdUnitID:reward: is deprecated and will be removed in a future version. Use OSGRewardedAdsDelegate.rewardedAdShouldRewardForAdUnitID:reward: instead.");

/**
 Called when an impression is fired on a Rewarded Video. Includes information about the impression if applicable.
 @deprecated This API is deprecated and will be removed in a future version.
 @param adUnitID The ad unit ID of the rewarded video that fired the impression.
 @param impressionData Information about the impression, or @c nil if the server didn't return any information.
 */
- (void)didTrackImpressionWithAdUnitID:(NSString *)adUnitID impressionData:(OSGImpressionData *)impressionData DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoDelegate.didTrackImpressionWithAdUnitID:impressionData: is deprecated and will be removed in a future version. Use OSGRewardedAdsDelegate.didTrackImpressionWithAdUnitID:impressionData: instead.");

@end
