//
//  OSGError.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>

extern NSString * const kNSErrorDomain;

typedef enum {
    OSGErrorUnknown = -1,
    OSGErrorNoInventory = 0,
    OSGErrorAdUnitWarmingUp = 1,
    OSGErrorNetworkTimedOut = 4,
    OSGErrorServerError = 8,
    OSGErrorAdapterNotFound = 16,
    OSGErrorAdapterInvalid = 17,
    OSGErrorAdapterHasNoInventory = 18,
    OSGErrorUnableToParseJSONAdResponse,
    OSGErrorUnexpectedNetworkResponse,
    OSGErrorHTTPResponseNot200,
    OSGErrorNoNetworkData,
    OSGErrorSDKNotInitialized,
    OSGErrorSDKInitializationInProgress,
    OSGErrorAdRequestTimedOut,
    OSGErrorNoRenderer,
    OSGErrorAdLoadAlreadyInProgress,
    OSGErrorInvalidCustomEventClass,
    OSGErrorJSONSerializationFailed,
    OSGErrorUnableToParseAdResponse,
    OSGErrorConsentDialogAlreadyShowing,
    OSGErrorNoConsentDialogLoaded,
    OSGErrorAdapterFailedToLoadAd,
    OSGErrorFullScreenAdAlreadyOnScreen,
    OSGErrorTooManyRequests,
    OSGErrorFrameWidthNotSetForFlexibleSize,
    OSGErrorFrameHeightNotSetForFlexibleSize,
    OSGErrorVideoPlayerFailedToPlay,
    OSGErrorNoHTMLToLoad,
    OSGErrorNoHTMLUrlToLoad,
    OSGErrorInlineNoViewGivenWhenAdLoaded,
    OSGErrorViewabilityNoViewToTrack,
    OSGErrorDuplicateURLRequest,
} OSGErrorCode;

@interface NSError (OSGError)

+ (NSError *)errorWithCode:(OSGErrorCode)code;
+ (NSError *)errorWithCode:(OSGErrorCode)code localizedDescription:(NSString *)description;

@end

@interface NSError (Initialization)
+ (instancetype)sdkMinimumOsVersion:(int)osVersion;
+ (instancetype)sdkInitializationInProgress;
@end

@interface NSError (AdLifeCycle)
+ (instancetype)adAlreadyLoading;
+ (instancetype)customEventClass:(Class)customEventClass doesNotInheritFrom:(Class)baseClass;
+ (instancetype)networkResponseIsNotHTTP;
+ (instancetype)networkResponseContainedNoData;
+ (instancetype)adLoadFailedBecauseSdkNotInitialized;
+ (instancetype)serializationOfJson:(NSDictionary *)json failedWithError:(NSError *)serializationError;
+ (instancetype)adResponseFailedToParseWithError:(NSError *)serializationError;
+ (instancetype)adResponsesNotFound;
+ (instancetype)fullscreenAdAlreadyOnScreen;
+ (instancetype)frameWidthNotSetForFlexibleSize;
+ (instancetype)frameHeightNotSetForFlexibleSize;
@end

@interface NSError (Consent)
+ (instancetype)consentDialogAlreadyShowing;
+ (instancetype)noConsentDialogLoaded;
@end

@interface NSError (RateLimit)
+ (instancetype)tooManyRequests;
@end

@interface NSError (Viewability)
+ (instancetype)noViewToTrack;
@end
