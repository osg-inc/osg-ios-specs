//
//  OSGRewardedVideoError.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>
#import "OSGRewardedAdsError.h"

typedef enum {
    OSGRewardedVideoAdErrorUnknown = -1,

    OSGRewardedVideoAdErrorTimeout = -1000,
    OSGRewardedVideoAdErrorAdUnitWarmingUp = -1001,
    OSGRewardedVideoAdErrorNoAdsAvailable = -1100,
    OSGRewardedVideoAdErrorInvalidCustomEvent = -1200,
    OSGRewardedVideoAdErrorMismatchingAdTypes = -1300,
    OSGRewardedVideoAdErrorAdAlreadyPlayed = -1400,
    OSGRewardedVideoAdErrorNoAdReady = -1401,
    OSGRewardedVideoAdErrorInvalidAdUnitID = -1500,
    OSGRewardedVideoAdErrorInvalidReward = -1600,
    OSGRewardedVideoAdErrorNoRewardSelected = -1601,
} OSGRewardedVideoErrorCode DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoError is deprecated and will be removed in a future version. Use OSGRewardedAdsError instead.");

extern NSString * const OSGRewardedVideoAdsErrorDomain DEPRECATED_MSG_ATTRIBUTE("OSGRewardedVideoAdsErrorDomain is deprecated and will be removed in a future version. Use OSGRewardedAdsErrorDomain instead.");
