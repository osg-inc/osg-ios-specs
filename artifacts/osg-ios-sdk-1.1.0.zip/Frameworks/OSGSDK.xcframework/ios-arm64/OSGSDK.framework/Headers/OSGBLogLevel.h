//
//  OSGBLogLevel.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <Foundation/Foundation.h>

/**
 SDK logging level. The "OSGB" prefix avoids namespace collision with the @c OSG entry class.
 @remark Lower values equate to more detailed logs.
 */
typedef NS_ENUM(NSUInteger, OSGBLogLevel) {
    OSGBLogLevelDebug = 20,
    OSGBLogLevelInfo  = 30,
    OSGBLogLevelNone  = 70
};
