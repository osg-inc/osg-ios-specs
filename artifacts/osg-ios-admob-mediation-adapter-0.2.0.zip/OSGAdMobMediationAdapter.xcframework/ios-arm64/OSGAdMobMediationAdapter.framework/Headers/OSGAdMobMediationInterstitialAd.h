//
//  OSGAdMobMediationInterstitialAd.h
//  osg-ios-admob-mediation-adapter
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

NS_ASSUME_NONNULL_BEGIN

@interface OSGAdMobMediationInterstitialAd : NSObject <GADMediationInterstitialAd>

- (instancetype)initWithAdConfiguration:(GADMediationInterstitialAdConfiguration *)adConfiguration;
- (void)loadWithCompletionHandler:(GADMediationInterstitialLoadCompletionHandler)completionHandler;

@end

NS_ASSUME_NONNULL_END
