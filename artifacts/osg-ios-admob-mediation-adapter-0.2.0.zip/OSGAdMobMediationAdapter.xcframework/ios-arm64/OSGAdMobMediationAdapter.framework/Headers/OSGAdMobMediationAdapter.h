//
//  OSGAdMobMediationAdapter.h
//  osg-ios-admob-mediation-adapter
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

NS_ASSUME_NONNULL_BEGIN

@interface OSGAdMobMediationAdapter : NSObject <GADMediationAdapter>

@end

NS_ASSUME_NONNULL_END
