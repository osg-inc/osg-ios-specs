#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "OSGAdMobMediationAdapter.h"
#import "OSGAdMobMediationBannerAd.h"
#import "OSGAdMobMediationConstants.h"
#import "OSGAdMobMediationCredentials.h"
#import "OSGAdMobMediationInterstitialAd.h"
#import "OSGAdMobMediationNativeAd.h"
#import "OSGAdMobMediationRewardedAd.h"
#import "OSGAdMobMediationSDKInitializer.h"
#import "OSGMediationNativeAdLoader.h"
#import "OSGMediationNativeRenderingView.h"

FOUNDATION_EXPORT double OSGAdMobMediationAdapterVersionNumber;
FOUNDATION_EXPORT const unsigned char OSGAdMobMediationAdapterVersionString[];

