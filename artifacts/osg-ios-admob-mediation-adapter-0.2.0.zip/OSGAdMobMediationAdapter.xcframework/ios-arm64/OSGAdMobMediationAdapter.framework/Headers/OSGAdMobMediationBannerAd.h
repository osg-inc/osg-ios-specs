//
//  OSGAdMobMediationBannerAd.h
//  osg-ios-admob-mediation-adapter
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

NS_ASSUME_NONNULL_BEGIN

@interface OSGAdMobMediationBannerAd : NSObject <GADMediationBannerAd>

- (instancetype)initWithAdConfiguration:(GADMediationBannerAdConfiguration *)adConfiguration;
- (void)loadWithCompletionHandler:(GADMediationBannerLoadCompletionHandler)completionHandler;

@end

NS_ASSUME_NONNULL_END
