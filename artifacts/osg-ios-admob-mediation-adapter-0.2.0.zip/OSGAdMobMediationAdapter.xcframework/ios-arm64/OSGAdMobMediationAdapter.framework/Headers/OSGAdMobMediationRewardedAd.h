//
//  OSGAdMobMediationRewardedAd.h
//  osg-ios-admob-mediation-adapter
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

NS_ASSUME_NONNULL_BEGIN

@interface OSGAdMobMediationRewardedAd : NSObject <GADMediationRewardedAd>

- (instancetype)initWithAdConfiguration:(GADMediationRewardedAdConfiguration *)adConfiguration;
- (void)loadWithCompletionHandler:(GADMediationRewardedLoadCompletionHandler)completionHandler;

@end

NS_ASSUME_NONNULL_END
