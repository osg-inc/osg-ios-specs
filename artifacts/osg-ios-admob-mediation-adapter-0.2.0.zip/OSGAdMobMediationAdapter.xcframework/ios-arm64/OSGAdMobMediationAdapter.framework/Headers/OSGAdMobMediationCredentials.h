//
//  OSGAdMobMediationCredentials.h
//  osg-ios-admob-mediation-adapter
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

NS_ASSUME_NONNULL_BEGIN

@interface OSGAdMobMediationCredentials : NSObject

@property (nonatomic, copy, readonly) NSString *adUnitId;
@property (nonatomic, copy, readonly, nullable) NSString *appId;
@property (nonatomic, copy, readonly, nullable) NSString *appKey;
@property (nonatomic, assign, readonly) BOOL testMode;

- (instancetype)initWithSettings:(NSDictionary<NSString *, id> *)settings;
- (nullable NSError *)validationError;

@end

NS_ASSUME_NONNULL_END
