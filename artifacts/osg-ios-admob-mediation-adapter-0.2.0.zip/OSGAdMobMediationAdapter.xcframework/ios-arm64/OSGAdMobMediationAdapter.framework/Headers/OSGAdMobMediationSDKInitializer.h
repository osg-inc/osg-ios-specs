//
//  OSGAdMobMediationSDKInitializer.h
//  osg-ios-admob-mediation-adapter
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface OSGAdMobMediationSDKInitializer : NSObject

+ (void)initializeIfNeededWithAdUnitId:(NSString *)adUnitId
                                appId:(nullable NSString *)appId
                               appKey:(nullable NSString *)appKey
                             testMode:(BOOL)testMode
                           completion:(void (^)(NSError * _Nullable error))completion;

@end

NS_ASSUME_NONNULL_END
