//
//  OSGAdMobMediationNativeAd.h
//  osg-ios-admob-mediation-adapter
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

NS_ASSUME_NONNULL_BEGIN

@interface OSGAdMobMediationNativeAd : NSObject <GADMediationNativeAd>

- (void)loadForAdConfiguration:(GADMediationNativeAdConfiguration *)adConfiguration
             completionHandler:(GADMediationNativeLoadCompletionHandler)completionHandler;

@end

NS_ASSUME_NONNULL_END
