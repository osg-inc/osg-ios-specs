//
//  OSGAdMobMediationConstants.h
//  osg-ios-admob-mediation-adapter
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// AdMob Mediation Custom Event / server parameter keys (configure in AdMob dashboard).
FOUNDATION_EXPORT NSString * const kOSGAdMobMediationAdUnitIdKey;
FOUNDATION_EXPORT NSString * const kOSGAdMobMediationAppIdKey;
FOUNDATION_EXPORT NSString * const kOSGAdMobMediationAppKeyKey;
FOUNDATION_EXPORT NSString * const kOSGAdMobMediationTestModeKey;

/// Adapter version reported to AdMob Mediation.
FOUNDATION_EXPORT NSString * const kOSGAdMobMediationAdapterVersion;

NS_ASSUME_NONNULL_END
