//
//  OSGConstants.h
//
//  Copyright 2025-2026 OSG, Inc.
//

#import <UIKit/UIKit.h>

#define OSG_HAS_NATIVE_PACKAGE       1

#define DEFAULT_PUB_ID              @"agltb3B1Yi1pbmNyDAsSBFNpdGUYkaoMDA"
#define OSG_SERVER_VERSION           @"8"
#define OSG_REWARDED_API_VERSION     @"1"
#define OSG_BUNDLE_IDENTIFIER        @"com.osg.sdk"
#define OSG_SDK_VERSION              @"1.0.2"

// Sizing constants.
extern CGSize const OSG_BANNER_SIZE __attribute__((deprecated("Use kOSGPresetMaxAdSizeMatchFrame, kOSGPresetMaxAdSizeMatchFrame, kOSGPresetMaxAdSize50Height, kMPPresetMaxAdSizeBanner90Height, kOSGPresetMaxAdSize90Height, kOSGPresetMaxAdSize250Height, kOSGPresetMaxAdSize280Height, or a custom maximum desired ad area instead")));
extern CGSize const OSG_MEDIUM_RECT_SIZE __attribute__((deprecated("Use kOSGPresetMaxAdSizeMatchFrame, kOSGPresetMaxAdSizeMatchFrame, kOSGPresetMaxAdSize50Height, kMPPresetMaxAdSizeBanner90Height, kOSGPresetMaxAdSize90Height, kOSGPresetMaxAdSize250Height, kOSGPresetMaxAdSize280Height, or a custom maximum desired ad area instead")));
extern CGSize const OSG_LEADERBOARD_SIZE __attribute__((deprecated("Use kOSGPresetMaxAdSizeMatchFrame, kOSGPresetMaxAdSizeMatchFrame, kOSGPresetMaxAdSize50Height, kMPPresetMaxAdSizeBanner90Height, kOSGPresetMaxAdSize90Height, kOSGPresetMaxAdSize250Height, kOSGPresetMaxAdSize280Height, or a custom maximum desired ad area instead")));
extern CGSize const OSG_WIDE_SKYSCRAPER_SIZE __attribute__((deprecated("Use kOSGPresetMaxAdSizeMatchFrame, kOSGPresetMaxAdSizeMatchFrame, kOSGPresetMaxAdSize50Height, kMPPresetMaxAdSizeBanner90Height, kOSGPresetMaxAdSize90Height, kOSGPresetMaxAdSize250Height, kOSGPresetMaxAdSize280Height, or a custom maximum desired ad area instead")));

// Convenience presets for requesting maximum ad sizes.
// Custom maximum ad sizes can be requested using an explicit `CGSize`.
extern CGSize const kOSGPresetMaxAdSizeMatchFrame;
extern CGSize const kOSGPresetMaxAdSize50Height;
extern CGSize const kOSGPresetMaxAdSize90Height;
extern CGSize const kOSGPresetMaxAdSize250Height;
extern CGSize const kOSGPresetMaxAdSize280Height;

/**
 Constant denoting that the dimension should be flexible with respect to
 the container.
 */
extern CGFloat const kOSGFlexibleAdSize;

// Miscellaneous constants.
#define MINIMUM_REFRESH_INTERVAL            10.0
#define DEFAULT_BANNER_REFRESH_INTERVAL     60    // seconds
#define BANNER_TIMEOUT_INTERVAL             10    // seconds
#define FULLSCREEN_TIMEOUT_INTERVAL         30    // seconds
#define NATIVE_TIMEOUT_INTERVAL             10    // seconds
#define OSG_ADS_EXPIRATION_INTERVAL       14400 // 4 hours converted to seconds

// Feature Flags
#define SESSION_TRACKING_ENABLED            1

@interface OSGConstants : NSObject

+ (NSTimeInterval)adsExpirationInterval;

@end
