//
//  OSGMediationNativeAdLoader.h
//  osg-ios-mediation-common
//

#import <Foundation/Foundation.h>

@class OSGNativeAd;
@class UIViewController;

NS_ASSUME_NONNULL_BEGIN

typedef void (^OSGMediationSDKInitializeBlock)(NSString *adUnitId,
                                               NSString * _Nullable appId,
                                               NSString * _Nullable appKey,
                                               BOOL testMode,
                                               void (^completion)(NSError * _Nullable error));

@interface OSGMediationNativeAdLoader : NSObject

+ (void)loadNativeAdWithAdUnitId:(NSString *)adUnitId
                          appId:(nullable NSString *)appId
                         appKey:(nullable NSString *)appKey
                       testMode:(BOOL)testMode
                     errorDomain:(NSString *)errorDomain
                 initializeSDK:(OSGMediationSDKInitializeBlock)initializeSDK
        presentingViewController:(UIViewController *)viewController
                      completion:(void (^)(OSGNativeAd * _Nullable nativeAd, UIView * _Nullable mediaView, NSError * _Nullable error))completion;

@end

NS_ASSUME_NONNULL_END
