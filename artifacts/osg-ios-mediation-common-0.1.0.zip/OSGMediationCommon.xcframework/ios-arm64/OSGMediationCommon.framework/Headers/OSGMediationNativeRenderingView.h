//
//  OSGMediationNativeRenderingView.h
//  osg-ios-mediation-common
//

#import <UIKit/UIKit.h>
#import <OSGSDK/OSGNativeAdRendering.h>

NS_ASSUME_NONNULL_BEGIN

@interface OSGMediationNativeRenderingView : UIView <OSGNativeAdRendering>

@end

NS_ASSUME_NONNULL_END
