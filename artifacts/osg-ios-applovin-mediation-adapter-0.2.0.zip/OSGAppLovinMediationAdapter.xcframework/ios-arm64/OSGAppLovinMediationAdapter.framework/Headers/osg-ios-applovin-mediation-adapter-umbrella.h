#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "OSGAppLovinMediationAdapter.h"
#import "OSGAppLovinMediationConstants.h"
#import "OSGAppLovinMediationCredentials.h"
#import "OSGAppLovinMediationNativeAd.h"
#import "OSGAppLovinMediationSDKInitializer.h"
#import "OSGMediationNativeAdLoader.h"
#import "OSGMediationNativeRenderingView.h"

FOUNDATION_EXPORT double OSGAppLovinMediationAdapterVersionNumber;
FOUNDATION_EXPORT const unsigned char OSGAppLovinMediationAdapterVersionString[];

