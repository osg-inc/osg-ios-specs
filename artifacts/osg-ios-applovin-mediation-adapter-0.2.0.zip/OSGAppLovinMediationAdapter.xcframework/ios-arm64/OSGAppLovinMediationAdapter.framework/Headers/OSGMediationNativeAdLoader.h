//
//  OSGMediationNativeAdLoader.h
//  osg-ios-applovin-mediation-adapter
//

#import <Foundation/Foundation.h>

@class OSGNativeAd;

NS_ASSUME_NONNULL_BEGIN

@interface OSGMediationNativeAdLoader : NSObject

+ (void)loadNativeAdWithAdUnitId:(NSString *)adUnitId
                          appId:(nullable NSString *)appId
                         appKey:(nullable NSString *)appKey
                       testMode:(BOOL)testMode
              presentingViewController:(UIViewController *)viewController
                      completion:(void (^)(OSGNativeAd * _Nullable nativeAd, UIView * _Nullable mediaView, NSError * _Nullable error))completion;

@end

NS_ASSUME_NONNULL_END
